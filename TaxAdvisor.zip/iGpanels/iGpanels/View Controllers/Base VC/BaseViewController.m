//
//  BaseViewController.m
//  IWasHere
//
//  Created by Qaiser Abbas on 21/10/2015.
//  Copyright © 2015 BirAlSabia. All rights reserved.
//

#import "BaseViewController.h"
#import "HomeViewController.h"
#import "ContactUsViewController.h"
#import "MainViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(IBAction) backButtonSelected:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)homeButtonTap:(UIButton *)sender
{
    bool alreadyPushed = false;
    //Check if the view was already pushed
    NSMutableArray *viewControllers;
    if ( (viewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers])) {
        
        for (UIViewController *aViewController in viewControllers) {
            
            if ([aViewController isKindOfClass:[HomeViewController class]]) {
                [self.navigationController popToViewController:aViewController animated:YES];
                alreadyPushed = true;
                break;
            }
        }
    }
    
    //Push Fresh View
    if( alreadyPushed == false)
    {
        HomeViewController* tableSelectionViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController pushViewController:tableSelectionViewController animated:YES];
    }

}

- (IBAction)shoppingButtonTap:(UIButton *)sender
{
    bool alreadyPushed = false;
    //Check if the view was already pushed
    NSMutableArray *viewControllers;
    if ( (viewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers])) {
        
        for (UIViewController *aViewController in viewControllers) {
            
            if ([aViewController isKindOfClass:[MainViewController class]]) {
                [self.navigationController popToViewController:aViewController animated:YES];
                alreadyPushed = true;
                break;
            }
        }
    }
    
    //Push Fresh View
    if( alreadyPushed == false)
    {
        MainViewController* tableSelectionViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewController"];
        [self.navigationController pushViewController:tableSelectionViewController animated:YES];
    }
    
}

- (IBAction)contactUsButtonTap:(UIButton *)sender
{
    bool alreadyPushed = false;
    //Check if the view was already pushed
    NSMutableArray *viewControllers;
    if ( (viewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers])) {
        
        for (UIViewController *aViewController in viewControllers) {
            
            if ([aViewController isKindOfClass:[ContactUsViewController class]]) {
                [self.navigationController popToViewController:aViewController animated:YES];
                alreadyPushed = true;
                break;
            }
        }
    }
    
    //Push Fresh View
    if( alreadyPushed == false)
    {
        ContactUsViewController* tableSelectionViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ContactUsViewController"];
        [self.navigationController pushViewController:tableSelectionViewController animated:YES];
    }
    
}

@end
