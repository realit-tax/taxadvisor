//
//  HomeViewController.h
//  Zigmapennys
//
//  Created by Qaiser Abbas on 9/27/17.
//  Copyright © 2017 Qaiser Abbas. All rights reserved.
//

#import "BaseViewController.h"

@interface HomeViewController : BaseViewController

@end
