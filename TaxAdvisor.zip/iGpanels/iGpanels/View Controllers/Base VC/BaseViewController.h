//
//  BaseViewController.h
//  IWasHere
//
//  Created by Qaiser Abbas on 21/10/2015.
//  Copyright © 2015 BirAlSabia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MBProgressHUD.h"

@interface BaseViewController : UIViewController
{
    
}


-(IBAction) backButtonSelected:(id)sender;

- (IBAction)homeButtonTap:(UIButton *)sender;
- (IBAction)shoppingButtonTap:(UIButton *)sender;
- (IBAction)contactUsButtonTap:(UIButton *)sender;


@end
